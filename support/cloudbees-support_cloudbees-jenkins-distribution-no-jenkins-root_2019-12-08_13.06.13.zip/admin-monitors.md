Monitors
========

`com.cloudbees.jenkins.plugins.advisor.Reminder`
--------------
(active and enabled)

`com.cloudbees.jenkins.plugins.assurance.SecurityWarningsWatch`
--------------
(active and enabled)

`jenkins.diagnostics.RootUrlNotSetMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
