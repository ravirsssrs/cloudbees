# Configuration

WAR Envelope detected [cloudbees-jenkins-distribution-2.190.3.2]
Installed Envelope detected [cloudbees-jenkins-distribution-2.190.3.2]
CloudBees Assurance Program enabled: true
Allow automatic upgrades of individual plugins on startup: false
Allow automatic downgrades of individual plugins on startup: false
Notify when security warnings affecting the core are detected: true
Notify when security warnings affecting plugins are detected: true

# Report

WARNING - Beekeeper Upgrade Assistant enabled on version 2.190.3.2. There are issues in the analyzed components.

## Items Requiring Attention

## Valid Items

* PLUGIN Jenkins Apache HttpComponents Client 4.x API Plugin (apache-httpcomponents-client-4-api)
    * Description: Correctly installed at version 4.5.10-2.0
    * Action: No action needed.

* PLUGIN Async Http Client (async-http-client)
    * Description: Correctly installed at version 1.7.24.2
    * Action: No action needed.

* PLUGIN Common API for Blue Ocean (blueocean-commons)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN bouncycastle API Plugin (bouncycastle-api)
    * Description: Correctly installed at version 2.17
    * Action: No action needed.

* PLUGIN CloudBees Administrative Monitors Plugin (cloudbees-administrative-monitors)
    * Description: Correctly installed at version 1.0.1
    * Action: No action needed.

* PLUGIN CloudBees Analytics Plugin (cloudbees-analytics)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Beekeeper Upgrade Assistant Plugin (cloudbees-assurance)
    * Description: Correctly installed at version 2.138.0.10
    * Action: No action needed.

* PLUGIN CloudBees Blue Ocean Default Theme (cloudbees-blueocean-default-theme)
    * Description: Correctly installed at version 0.5
    * Action: No action needed.

* PLUGIN Folders Plugin (cloudbees-folder)
    * Description: Correctly installed at version 6.9
    * Action: No action needed.

* PLUGIN Jenkins Health Advisor by CloudBees (cloudbees-jenkins-advisor)
    * Description: Correctly installed at version 3.0
    * Action: No action needed.

* PLUGIN CloudBees License Manager (cloudbees-license)
    * Description: Correctly installed at version 9.35
    * Action: No action needed.

* PLUGIN CloudBees Support Plugin (cloudbees-support)
    * Description: Correctly installed at version 3.22
    * Action: No action needed.

* PLUGIN CloudBees Update Center Data API (cloudbees-uc-data-api)
    * Description: Correctly installed at version 4.42
    * Action: No action needed.

* PLUGIN Command Agent Launcher Plugin (command-launcher)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Configuration as Code Plugin (configuration-as-code)
    * Description: Correctly installed at version 1.30
    * Action: No action needed.

* PLUGIN Credentials Plugin (credentials)
    * Description: Correctly installed at version 2.3.0
    * Action: No action needed.

* PLUGIN Display URL API (display-url-api)
    * Description: Correctly installed at version 2.3.1
    * Action: No action needed.

* PLUGIN Jackson 2 API Plugin (jackson2-api)
    * Description: Correctly installed at version 2.10.0
    * Action: No action needed.

* PLUGIN JAXB plugin (jaxb)
    * Description: Correctly installed at version 2.3.0.1
    * Action: No action needed.

* PLUGIN Oracle Java SE Development Kit Installer Plugin (jdk-tool)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN JUnit Plugin (junit)
    * Description: Correctly installed at version 1.28
    * Action: No action needed.

* PLUGIN Jenkins Mailer Plugin (mailer)
    * Description: Correctly installed at version 1.29
    * Action: No action needed.

* PLUGIN MapDB API Plugin (mapdb-api)
    * Description: Correctly installed at version 1.0.9.0
    * Action: No action needed.

* PLUGIN Metrics Plugin (metrics)
    * Description: Correctly installed at version 4.0.2.6
    * Action: No action needed.

* PLUGIN CloudBees Jenkins Enterprise License Entitlement Check (nectar-license)
    * Description: Correctly installed at version 8.24
    * Action: No action needed.

* PLUGIN SCM API Plugin (scm-api)
    * Description: Correctly installed at version 2.6.3
    * Action: No action needed.

* PLUGIN Script Security Plugin (script-security)
    * Description: Correctly installed at version 1.66
    * Action: No action needed.

* PLUGIN Structs Plugin (structs)
    * Description: Correctly installed at version 1.20
    * Action: No action needed.

* PLUGIN Support Core Plugin (support-core)
    * Description: Correctly installed at version 2.62
    * Action: No action needed.

* PLUGIN Token Macro Plugin (token-macro)
    * Description: Correctly installed at version 2.8
    * Action: No action needed.

* PLUGIN Trilead API Plugin (trilead-api)
    * Description: Correctly installed at version 1.0.5
    * Action: No action needed.

* PLUGIN Variant Plugin (variant)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Pipeline: API (workflow-api)
    * Description: Correctly installed at version 2.37
    * Action: No action needed.

* PLUGIN Pipeline: Step API (workflow-step-api)
    * Description: Correctly installed at version 2.20
    * Action: No action needed.

## Plugin Catalog

Not installed
