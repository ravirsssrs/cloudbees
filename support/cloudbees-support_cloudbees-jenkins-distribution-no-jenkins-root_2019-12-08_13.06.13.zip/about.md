Jenkins
=======

Version details
---------------

  * Version: `2.190.3.2`
  * Instance ID: `af2240e73e19c90e07c8e15eda2367db`
  * Mode:    WAR
  * Url:     null
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;232
      - Maximum memory:   199.19 MB (208863232)
      - Allocated memory: 124.15 MB (130179072)
      - Free memory:      23.44 MB (24576048)
      - In-use memory:    100.71 MB (105603024)
      - GC strategy:      SerialGC
      - Available CPUs:   1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.232-b09
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.18.0-80.4.2.el8&#95;0.x86&#95;64
  * Process ID: 14624 (0x3920)
  * Process started: 2019-12-08 13:02:47.371+0000
  * Process uptime: 3 min 27 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/classes`
      - Classpath: `/usr/lib/cloudbees-jenkins-distribution/cloudbees-jenkins-distribution.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-DJENKINS_HOME=/var/lib/cloudbees-jenkins-distribution`
      - arg[3]: `-Dcb.distributable.name=RedHat / Fedora RPM`
      - arg[4]: `-Dcb.distributable.commit_sha=83c3b14729e95f8cafcfff2c9ff31fb5582c2a92`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * async-http-client:1.7.24.2 'Async Http Client'
  * blueocean-commons:1.19.0 'Common API for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * cloudbees-administrative-monitors:1.0.1 'CloudBees Administrative Monitors Plugin'
  * cloudbees-analytics:1.3 'CloudBees Analytics Plugin'
  * cloudbees-assurance:2.138.0.10 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-blueocean-default-theme:0.5 'CloudBees Blue Ocean Default Theme'
  * cloudbees-folder:6.9 'Folders Plugin'
  * cloudbees-jenkins-advisor:3.0 'Jenkins Health Advisor by CloudBees'
  * cloudbees-license:9.35 'CloudBees License Manager'
  * cloudbees-support:3.22 'CloudBees Support Plugin'
  * cloudbees-uc-data-api:4.42 'CloudBees Update Center Data API'
  * command-launcher:1.3 'Command Agent Launcher Plugin'
  * configuration-as-code:1.30 'Configuration as Code Plugin'
  * credentials:2.3.0 'Credentials Plugin'
  * display-url-api:2.3.1 'Display URL API'
  * jackson2-api:2.10.0 'Jackson 2 API Plugin'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.3 'Oracle Java SE Development Kit Installer Plugin'
  * junit:1.28 'JUnit Plugin'
  * mailer:1.29 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * nectar-license:8.24 'CloudBees Jenkins Enterprise License Entitlement Check'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.66 'Script Security Plugin'
  * structs:1.20 'Structs Plugin'
  * support-core:2.62 'Support Core Plugin'
  * token-macro:2.8 'Token Macro Plugin'
  * trilead-api:1.0.5 'Trilead API Plugin'
  * variant:1.3 'Variant Plugin'
  * workflow-api:2.37 'Pipeline: API'
  * workflow-step-api:2.20 'Pipeline: Step API'

Packaging details
-----------------

#UNKNOWN#

CloudBees Product Description
-----------------------------

 * Product Distribution: rolling 
 * Product Id: cloudbees-jenkins-distribution 
 * Product Name: CloudBees Jenkins Distribution 
 * Product Solution: CloudBees Jenkins Distribution 
 * Product Userfacingsolution: CloudBees Jenkins Distribution 
 * Product Version: 2.190.3.2 

CloudBees Distributable Description
-----------------------------------

 * Distributable Name: RedHat / Fedora RPM
 * UDR Commit SHA: 83c3b14729e95f8cafcfff2c9ff31fb5582c2a92

License details
---------------

 * Jenkins Instance ID:  `af2240e73e19c90e07c8e15eda2367db`
 * NO VALID LICENSE INSTALLED
