Node statistics
===============

  * Total number of nodes
      - Sample size:        12
      - Average (mean):     1.0000000000000002
      - Average (median):   1.0
      - Standard deviation: 2.220446049250313E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        12
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        12
      - Average (mean):     2.0000000000000004
      - Average (median):   2.0
      - Standard deviation: 4.440892098500626E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        12
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/cloudbees-jenkins-distribution`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.33
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;232
          + Maximum memory:   199.19 MB (208863232)
          + Allocated memory: 124.15 MB (130179072)
          + Free memory:      19.86 MB (20822472)
          + In-use memory:    104.29 MB (109356600)
          + GC strategy:      SerialGC
          + Available CPUs:   1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.232-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.18.0-80.4.2.el8&#95;0.x86&#95;64
      - Process ID: 14624 (0x3920)
      - Process started: 2019-12-08 13:02:47.371+0000
      - Process uptime: 3 min 27 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/classes`
          + Classpath: `/usr/lib/cloudbees-jenkins-distribution/cloudbees-jenkins-distribution.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-DJENKINS_HOME=/var/lib/cloudbees-jenkins-distribution`
          + arg[3]: `-Dcb.distributable.name=RedHat / Fedora RPM`
          + arg[4]: `-Dcb.distributable.commit_sha=83c3b14729e95f8cafcfff2c9ff31fb5582c2a92`

