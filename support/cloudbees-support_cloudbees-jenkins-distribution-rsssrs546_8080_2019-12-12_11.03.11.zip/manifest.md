CloudBees Support Bundle Manifest
=================================

Generated on 2019-12-12 11:03:11.434+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2019-12-08_13.03.00.log`

      - `nodes/master/logs/all_2019-12-09_05.40.30.log`

      - `nodes/master/logs/all_2019-12-12_08.59.11.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Bundle Upload.log`

      - `other-logs/Bundle Upload.log.1`

      - `other-logs/Bundle Upload.log.2`

      - `other-logs/Check if license is expired.log`

      - `other-logs/Check if license is expired.log.1`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/com.cloudbees.jenkins.support.impl.cloudbees.IOPerfPeriodicWork.log`

      - `other-logs/com.cloudbees.jenkins.support.impl.cloudbees.IOPerfPeriodicWork.log.1`

      - `other-logs/com.cloudbees.jenkins.support.impl.cloudbees.IOPerfPeriodicWork.log.2`

      - `other-logs/health-checker.log`

      - `other-logs/jobAnalytics.log`

  * Agent Log Recorders

      - `nodes/slave/test/jenkins.log`

      - `nodes/slave/test/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * CloudBees Assurance Program

      - `cap/beekeeper.md`

      - `cap/properties.md`

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/test/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cloudbees.analytics.gatherer.RandomPersistentInstanceId.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.advisor.AdvisorGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.license.RegistrationStateConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.gradle.Gradle.xml`

      - `jenkins-root-configuration-files/hudson.plugins.mercurial.MercurialInstallation.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.telemetry.Correlator.xml`

      - `jenkins-root-configuration-files/license.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

  * About browser

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/test/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/test/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/test/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * Items Content (Computationally expensive)

  * Agent JVM process system metrics (Linux only)

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/QA/gnuplot`

      - `load-stats/label/QA/hour.csv`

      - `load-stats/label/QA/min.csv`

      - `load-stats/label/QA/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/test/gnuplot`

      - `load-stats/label/test/hour.csv`

      - `load-stats/label/test/min.csv`

      - `load-stats/label/test/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/test/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

      - `nodes/slave/test/RootCA.txt`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

  * Agent system configuration (Linux only)

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/test/system.properties`

  * Update Center

      - `update-center.md`

  * Out Of Memory Errors

      - `/nodes/master/oome.md`

  * Slow Request Records

      - `slow-requests/20191209-170653.047.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/test/thread-dump.txt`

