=== Sites ===
 - Url: file:/var/cache/cloudbees-jenkins-distribution/war/WEB-INF/plugins/update-center.json
 - Connection Url: file:/var/cache/cloudbees-jenkins-distribution/war/WEB-INF/plugins/update-center.json
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
 - Url: https://jenkins-updates.cloudbees.com/update-center/envelope-cloudbees-jenkins-distribution/update-center.json
 - Connection Url: null
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
======
Last updated: 9 hr 5 min
=== Proxy ===
