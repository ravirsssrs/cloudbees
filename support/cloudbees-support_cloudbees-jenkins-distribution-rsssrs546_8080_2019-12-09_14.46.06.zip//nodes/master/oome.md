OutOfMemoryError Statistics
===========================

  * Time of first OOME: N/A
