Jenkins
=======

Version details
---------------

  * Version: `2.190.3.2`
  * Instance ID: `af2240e73e19c90e07c8e15eda2367db`
  * Mode:    WAR
  * Url:     http://rsssrs546:8080/
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;232
      - Maximum memory:   199.19 MB (208863232)
      - Allocated memory: 199.19 MB (208863232)
      - Free memory:      93.00 MB (97517736)
      - In-use memory:    106.19 MB (111345496)
      - GC strategy:      SerialGC
      - Available CPUs:   1
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.232-b09
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.18.0-80.4.2.el8&#95;0.x86&#95;64
  * Process ID: 24505 (0x5fb9)
  * Process started: 2019-12-09 05:40:21.940+0000
  * Process uptime: 9 hr 5 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.232.b09-2.el8_1.x86_64/jre/classes`
      - Classpath: `/usr/lib/cloudbees-jenkins-distribution/cloudbees-jenkins-distribution.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-DJENKINS_HOME=/var/lib/cloudbees-jenkins-distribution`
      - arg[3]: `-Dcb.distributable.name=RedHat / Fedora RPM`
      - arg[4]: `-Dcb.distributable.commit_sha=83c3b14729e95f8cafcfff2c9ff31fb5582c2a92`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * async-http-client:1.7.24.2 'Async Http Client'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.19.0 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.19.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.19.0 'Common API for Blue Ocean'
  * blueocean-config:1.19.0 'Config API for Blue Ocean'
  * blueocean-core-js:1.19.0 'Blue Ocean Core JS'
  * blueocean-dashboard:1.19.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.3.0 'Display URL for Blue Ocean'
  * blueocean-events:1.19.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.19.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.19.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.19.0 'i18n for Blue Ocean'
  * blueocean-jira:1.19.0 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.19.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.19.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.19.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.19.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.19.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.19.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.19.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.19.0 'Web for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.5.4 'Branch API Plugin'
  * cloudbees-administrative-monitors:1.0.1 'CloudBees Administrative Monitors Plugin'
  * cloudbees-analytics:1.3 'CloudBees Analytics Plugin'
  * cloudbees-assurance:2.138.0.10 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-bitbucket-branch-source:2.5.0 'Bitbucket Branch Source Plugin'
  * cloudbees-blueocean-default-theme:0.5 'CloudBees Blue Ocean Default Theme'
  * cloudbees-folder:6.9 'Folders Plugin'
  * cloudbees-jenkins-advisor:3.0 'Jenkins Health Advisor by CloudBees'
  * cloudbees-license:9.35 'CloudBees License Manager'
  * cloudbees-support:3.22 'CloudBees Support Plugin'
  * cloudbees-uc-data-api:4.42 'CloudBees Update Center Data API'
  * command-launcher:1.3 'Command Agent Launcher Plugin'
  * configuration-as-code:1.30 'Configuration as Code Plugin'
  * credentials:2.3.0 'Credentials Plugin'
  * credentials-binding:1.20 'Credentials Binding Plugin'
  * display-url-api:2.3.1 'Display URL API'
  * docker-commons:1.15 'Docker Commons Plugin'
  * docker-workflow:1.21 'Docker Pipeline'
  * durable-task:1.30 'Durable Task Plugin'
  * email-ext:2.68 'Email Extension Plugin'
  * favorite:2.3.2 'Favorite'
  * folder-auth:1.1 'Folder-based Authorization Strategy'
  * git:3.12.1 'Jenkins Git plugin'
  * git-client:2.9.0 'Jenkins Git client plugin'
  * git-parameter:0.9.11 'Git Parameter Plug-In'
  * git-server:1.8 'Jenkins GIT server Plugin'
  * github:1.29.4 'GitHub plugin'
  * github-api:1.95 'GitHub API Plugin'
  * github-branch-source:2.5.8 'GitHub Branch Source Plugin'
  * gradle:1.30 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.7-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.21 'HTML Publisher plugin'
  * jackson2-api:2.10.0 'Jackson 2 API Plugin'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.3 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.19.0 'Jenkins Design Language'
  * jira:3.0.10 'Jenkins JIRA plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55.1 'Jenkins JSch dependency plugin'
  * junit:1.28 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * mailer:1.29 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * mercurial:2.8 'Jenkins Mercurial plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nectar-license:8.24 'CloudBees Jenkins Enterprise License Entitlement Check'
  * pipeline-build-step:2.9 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.11 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.9 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.9 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.12 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.9 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.12 'Pipeline: Stage View Plugin'
  * plain-credentials:1.5 'Plain Credentials Plugin'
  * pubsub-light:1.13 'Jenkins Pub-Sub "light" Bus'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.66 'Script Security Plugin'
  * sse-gateway:1.20 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-agent:1.17 'SSH Agent Plugin'
  * ssh-credentials:1.18 'SSH Credentials Plugin'
  * ssh-slaves:1.31.0 'Jenkins SSH Slaves plugin'
  * structs:1.20 'Structs Plugin'
  * support-core:2.62 'Support Core Plugin'
  * token-macro:2.8 'Token Macro Plugin'
  * trilead-api:1.0.5 'Trilead API Plugin'
  * variant:1.3 'Variant Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.37 'Pipeline: API'
  * workflow-basic-steps:2.18 'Pipeline: Basic Steps'
  * workflow-cps:2.74 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.15 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.34 'Pipeline: Nodes and Processes'
  * workflow-job:2.35 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.9 'Pipeline: SCM Step'
  * workflow-step-api:2.20 'Pipeline: Step API'
  * workflow-support:3.3 'Pipeline: Supporting APIs'

Packaging details
-----------------

#UNKNOWN#

CloudBees Product Description
-----------------------------

 * Product Distribution: rolling 
 * Product Id: cloudbees-jenkins-distribution 
 * Product Name: CloudBees Jenkins Distribution 
 * Product Solution: CloudBees Jenkins Distribution 
 * Product Userfacingsolution: CloudBees Jenkins Distribution 
 * Product Version: 2.190.3.2 

CloudBees Distributable Description
-----------------------------------

 * Distributable Name: RedHat / Fedora RPM
 * UDR Commit SHA: 83c3b14729e95f8cafcfff2c9ff31fb5582c2a92

License details
---------------

 * Jenkins Instance ID:  `af2240e73e19c90e07c8e15eda2367db`
 * Expires:              2029-12-06 23:59:59.000+0000
 * Issued to:            ravisys546@gmail.com
 * Organization:         
     - CloudBees Jenkins Distribution licensed for 10,000 users
