Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * test: null
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * test: null
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 7.214GB left on /var/lib/cloudbees-jenkins-distribution.
   * test: null
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:52/819MB  Swap:0/0MB
   * test: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 7.214GB left on /tmp.
   * test: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * test: null
