# Configuration

WAR Envelope detected [cloudbees-jenkins-distribution-2.190.3.2]
Installed Envelope detected [cloudbees-jenkins-distribution-2.190.3.2]
CloudBees Assurance Program enabled: true
Allow automatic upgrades of individual plugins on startup: false
Allow automatic downgrades of individual plugins on startup: false
Notify when security warnings affecting the core are detected: true
Notify when security warnings affecting plugins are detected: true

# Report

WARNING - Beekeeper Upgrade Assistant enabled on version 2.190.3.2. There are issues in the analyzed components.

## Items Requiring Attention

## Valid Items

* PLUGIN JavaScript GUI Lib: ACE Editor bundle plugin (ace-editor)
    * Description: Correctly installed at version 1.1
    * Action: No action needed.

* PLUGIN Jenkins Apache HttpComponents Client 4.x API Plugin (apache-httpcomponents-client-4-api)
    * Description: Correctly installed at version 4.5.10-2.0
    * Action: No action needed.

* PLUGIN Async Http Client (async-http-client)
    * Description: Correctly installed at version 1.7.24.2
    * Action: No action needed.

* PLUGIN Authentication Tokens API Plugin (authentication-tokens)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Blue Ocean (blueocean)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Autofavorite for Blue Ocean (blueocean-autofavorite)
    * Description: Correctly installed at version 1.2.4
    * Action: No action needed.

* PLUGIN Bitbucket Pipeline for Blue Ocean (blueocean-bitbucket-pipeline)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Common API for Blue Ocean (blueocean-commons)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Config API for Blue Ocean (blueocean-config)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Blue Ocean Core JS (blueocean-core-js)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Dashboard for Blue Ocean (blueocean-dashboard)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Display URL for Blue Ocean (blueocean-display-url)
    * Description: Correctly installed at version 2.3.0
    * Action: No action needed.

* PLUGIN Events API for Blue Ocean (blueocean-events)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Git Pipeline for Blue Ocean (blueocean-git-pipeline)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN GitHub Pipeline for Blue Ocean (blueocean-github-pipeline)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN i18n for Blue Ocean (blueocean-i18n)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN JIRA Integration for Blue Ocean (blueocean-jira)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN JWT for Blue Ocean (blueocean-jwt)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Personalization for Blue Ocean (blueocean-personalization)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Pipeline implementation for Blue Ocean (blueocean-pipeline-api-impl)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Blue Ocean Pipeline Editor (blueocean-pipeline-editor)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Pipeline SCM API for Blue Ocean (blueocean-pipeline-scm-api)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN REST API for Blue Ocean (blueocean-rest)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN REST Implementation for Blue Ocean (blueocean-rest-impl)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Web for Blue Ocean (blueocean-web)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN bouncycastle API Plugin (bouncycastle-api)
    * Description: Correctly installed at version 2.17
    * Action: No action needed.

* PLUGIN Branch API Plugin (branch-api)
    * Description: Correctly installed at version 2.5.4
    * Action: No action needed.

* PLUGIN CloudBees Administrative Monitors Plugin (cloudbees-administrative-monitors)
    * Description: Correctly installed at version 1.0.1
    * Action: No action needed.

* PLUGIN CloudBees Analytics Plugin (cloudbees-analytics)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Beekeeper Upgrade Assistant Plugin (cloudbees-assurance)
    * Description: Correctly installed at version 2.138.0.10
    * Action: No action needed.

* PLUGIN Bitbucket Branch Source Plugin (cloudbees-bitbucket-branch-source)
    * Description: Correctly installed at version 2.5.0
    * Action: No action needed.

* PLUGIN CloudBees Blue Ocean Default Theme (cloudbees-blueocean-default-theme)
    * Description: Correctly installed at version 0.5
    * Action: No action needed.

* PLUGIN Folders Plugin (cloudbees-folder)
    * Description: Correctly installed at version 6.9
    * Action: No action needed.

* PLUGIN Jenkins Health Advisor by CloudBees (cloudbees-jenkins-advisor)
    * Description: Correctly installed at version 3.0
    * Action: No action needed.

* PLUGIN CloudBees License Manager (cloudbees-license)
    * Description: Correctly installed at version 9.35
    * Action: No action needed.

* PLUGIN CloudBees Support Plugin (cloudbees-support)
    * Description: Correctly installed at version 3.22
    * Action: No action needed.

* PLUGIN CloudBees Update Center Data API (cloudbees-uc-data-api)
    * Description: Correctly installed at version 4.42
    * Action: No action needed.

* PLUGIN Command Agent Launcher Plugin (command-launcher)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Configuration as Code Plugin (configuration-as-code)
    * Description: Correctly installed at version 1.30
    * Action: No action needed.

* PLUGIN Credentials Plugin (credentials)
    * Description: Correctly installed at version 2.3.0
    * Action: No action needed.

* PLUGIN Credentials Binding Plugin (credentials-binding)
    * Description: Correctly installed at version 1.20
    * Action: No action needed.

* PLUGIN Display URL API (display-url-api)
    * Description: Correctly installed at version 2.3.1
    * Action: No action needed.

* PLUGIN Docker Commons Plugin (docker-commons)
    * Description: Correctly installed at version 1.15
    * Action: No action needed.

* PLUGIN Docker Pipeline (docker-workflow)
    * Description: Correctly installed at version 1.21
    * Action: No action needed.

* PLUGIN Durable Task Plugin (durable-task)
    * Description: Correctly installed at version 1.30
    * Action: No action needed.

* PLUGIN Email Extension Plugin (email-ext)
    * Description: Correctly installed at version 2.68
    * Action: No action needed.

* PLUGIN Favorite (favorite)
    * Description: Correctly installed at version 2.3.2
    * Action: No action needed.

* PLUGIN Jenkins Git plugin (git)
    * Description: Correctly installed at version 3.12.1
    * Action: No action needed.

* PLUGIN Jenkins Git client plugin (git-client)
    * Description: Correctly installed at version 2.9.0
    * Action: No action needed.

* PLUGIN Jenkins GIT server Plugin (git-server)
    * Description: Correctly installed at version 1.8
    * Action: No action needed.

* PLUGIN GitHub plugin (github)
    * Description: Correctly installed at version 1.29.4
    * Action: No action needed.

* PLUGIN GitHub API Plugin (github-api)
    * Description: Correctly installed at version 1.95
    * Action: No action needed.

* PLUGIN GitHub Branch Source Plugin (github-branch-source)
    * Description: Correctly installed at version 2.5.8
    * Action: No action needed.

* PLUGIN Gradle Plugin (gradle)
    * Description: Correctly installed at version 1.30
    * Action: No action needed.

* PLUGIN JavaScript GUI Lib: Handlebars bundle plugin (handlebars)
    * Description: Correctly installed at version 1.1.1
    * Action: No action needed.

* PLUGIN Handy Uri Templates 2.x API Plugin (handy-uri-templates-2-api)
    * Description: Correctly installed at version 2.1.7-1.0
    * Action: No action needed.

* PLUGIN HTML Publisher plugin (htmlpublisher)
    * Description: Correctly installed at version 1.21
    * Action: No action needed.

* PLUGIN Jackson 2 API Plugin (jackson2-api)
    * Description: Correctly installed at version 2.10.0
    * Action: No action needed.

* PLUGIN JAXB plugin (jaxb)
    * Description: Correctly installed at version 2.3.0.1
    * Action: No action needed.

* PLUGIN Oracle Java SE Development Kit Installer Plugin (jdk-tool)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Jenkins Design Language (jenkins-design-language)
    * Description: Correctly installed at version 1.19.0
    * Action: No action needed.

* PLUGIN Jenkins JIRA plugin (jira)
    * Description: Correctly installed at version 3.0.10
    * Action: No action needed.

* PLUGIN jQuery plugin (jquery)
    * Description: Correctly installed at version 1.12.4-1
    * Action: No action needed.

* PLUGIN JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin (jquery-detached)
    * Description: Correctly installed at version 1.2.1
    * Action: No action needed.

* PLUGIN Jenkins JSch dependency plugin (jsch)
    * Description: Correctly installed at version 0.1.55.1
    * Action: No action needed.

* PLUGIN JUnit Plugin (junit)
    * Description: Correctly installed at version 1.28
    * Action: No action needed.

* PLUGIN LDAP Plugin (ldap)
    * Description: Correctly installed at version 1.20
    * Action: No action needed.

* PLUGIN Jenkins Mailer Plugin (mailer)
    * Description: Correctly installed at version 1.29
    * Action: No action needed.

* PLUGIN MapDB API Plugin (mapdb-api)
    * Description: Correctly installed at version 1.0.9.0
    * Action: No action needed.

* PLUGIN Matrix Authorization Strategy Plugin (matrix-auth)
    * Description: Correctly installed at version 2.5
    * Action: No action needed.

* PLUGIN Matrix Project Plugin (matrix-project)
    * Description: Correctly installed at version 1.14
    * Action: No action needed.

* PLUGIN Jenkins Mercurial plugin (mercurial)
    * Description: Correctly installed at version 2.8
    * Action: No action needed.

* PLUGIN Metrics Plugin (metrics)
    * Description: Correctly installed at version 4.0.2.6
    * Action: No action needed.

* PLUGIN JavaScript GUI Lib: Moment.js bundle plugin (momentjs)
    * Description: Correctly installed at version 1.1.1
    * Action: No action needed.

* PLUGIN CloudBees Jenkins Enterprise License Entitlement Check (nectar-license)
    * Description: Correctly installed at version 8.24
    * Action: No action needed.

* PLUGIN Pipeline: Build Step (pipeline-build-step)
    * Description: Correctly installed at version 2.9
    * Action: No action needed.

* PLUGIN Pipeline Graph Analysis Plugin (pipeline-graph-analysis)
    * Description: Correctly installed at version 1.10
    * Action: No action needed.

* PLUGIN Pipeline: Input Step (pipeline-input-step)
    * Description: Correctly installed at version 2.11
    * Action: No action needed.

* PLUGIN Pipeline: Milestone Step (pipeline-milestone-step)
    * Description: Correctly installed at version 1.3.1
    * Action: No action needed.

* PLUGIN Pipeline: Model API (pipeline-model-api)
    * Description: Correctly installed at version 1.3.9
    * Action: No action needed.

* PLUGIN Pipeline: Declarative Agent API (pipeline-model-declarative-agent)
    * Description: Correctly installed at version 1.1.1
    * Action: No action needed.

* PLUGIN Pipeline: Declarative (pipeline-model-definition)
    * Description: Correctly installed at version 1.3.9
    * Action: No action needed.

* PLUGIN Pipeline: Declarative Extension Points API (pipeline-model-extensions)
    * Description: Correctly installed at version 1.3.9
    * Action: No action needed.

* PLUGIN Pipeline: REST API Plugin (pipeline-rest-api)
    * Description: Correctly installed at version 2.12
    * Action: No action needed.

* PLUGIN Pipeline: Stage Step (pipeline-stage-step)
    * Description: Correctly installed at version 2.3
    * Action: No action needed.

* PLUGIN Pipeline: Stage Tags Metadata (pipeline-stage-tags-metadata)
    * Description: Correctly installed at version 1.3.9
    * Action: No action needed.

* PLUGIN Pipeline: Stage View Plugin (pipeline-stage-view)
    * Description: Correctly installed at version 2.12
    * Action: No action needed.

* PLUGIN Plain Credentials Plugin (plain-credentials)
    * Description: Correctly installed at version 1.5
    * Action: No action needed.

* PLUGIN Jenkins Pub-Sub "light" Bus (pubsub-light)
    * Description: Correctly installed at version 1.13
    * Action: No action needed.

* PLUGIN SCM API Plugin (scm-api)
    * Description: Correctly installed at version 2.6.3
    * Action: No action needed.

* PLUGIN Script Security Plugin (script-security)
    * Description: Correctly installed at version 1.66
    * Action: No action needed.

* PLUGIN Server Sent Events (SSE) Gateway Plugin (sse-gateway)
    * Description: Correctly installed at version 1.20
    * Action: No action needed.

* PLUGIN SSH Agent Plugin (ssh-agent)
    * Description: Correctly installed at version 1.17
    * Action: No action needed.

* PLUGIN SSH Credentials Plugin (ssh-credentials)
    * Description: Correctly installed at version 1.18
    * Action: No action needed.

* PLUGIN Jenkins SSH Slaves plugin (ssh-slaves)
    * Description: Correctly installed at version 1.31.0
    * Action: No action needed.

* PLUGIN Structs Plugin (structs)
    * Description: Correctly installed at version 1.20
    * Action: No action needed.

* PLUGIN Support Core Plugin (support-core)
    * Description: Correctly installed at version 2.62
    * Action: No action needed.

* PLUGIN Token Macro Plugin (token-macro)
    * Description: Correctly installed at version 2.8
    * Action: No action needed.

* PLUGIN Trilead API Plugin (trilead-api)
    * Description: Correctly installed at version 1.0.5
    * Action: No action needed.

* PLUGIN Variant Plugin (variant)
    * Description: Correctly installed at version 1.3
    * Action: No action needed.

* PLUGIN Pipeline (workflow-aggregator)
    * Description: Correctly installed at version 2.5
    * Action: No action needed.

* PLUGIN Pipeline: API (workflow-api)
    * Description: Correctly installed at version 2.37
    * Action: No action needed.

* PLUGIN Pipeline: Basic Steps (workflow-basic-steps)
    * Description: Correctly installed at version 2.18
    * Action: No action needed.

* PLUGIN Pipeline: Groovy (workflow-cps)
    * Description: Correctly installed at version 2.74
    * Action: No action needed.

* PLUGIN Pipeline: Shared Groovy Libraries (workflow-cps-global-lib)
    * Description: Correctly installed at version 2.15
    * Action: No action needed.

* PLUGIN Pipeline: Nodes and Processes (workflow-durable-task-step)
    * Description: Correctly installed at version 2.34
    * Action: No action needed.

* PLUGIN Pipeline: Job (workflow-job)
    * Description: Correctly installed at version 2.35
    * Action: No action needed.

* PLUGIN Pipeline: Multibranch (workflow-multibranch)
    * Description: Correctly installed at version 2.21
    * Action: No action needed.

* PLUGIN Pipeline: SCM Step (workflow-scm-step)
    * Description: Correctly installed at version 2.9
    * Action: No action needed.

* PLUGIN Pipeline: Step API (workflow-step-api)
    * Description: Correctly installed at version 2.20
    * Action: No action needed.

* PLUGIN Pipeline: Supporting APIs (workflow-support)
    * Description: Correctly installed at version 3.3
    * Action: No action needed.

## Plugin Catalog

Not installed
